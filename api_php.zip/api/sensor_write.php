<?php
date_default_timezone_set("Asia/Kolkata");
error_reporting(E_ALL);
ini_set('display_errors', 1);
$servername = "localhost";
$username = "virtualw_api";
$password = "virtualw_api";
$dbname = "virtualw_api";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$name = 'default';
if(isset($_REQUEST['status'])){
	$name = $_REQUEST['status'];
}
if($name!='default' && $name!=null && $name!=''){
    $sql = "INSERT INTO sensor (status) VALUES ('$name')";
    
    if ($conn->query($sql) === TRUE) {
        echo "SUCCESS##New record created successfully##OKEND##";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>