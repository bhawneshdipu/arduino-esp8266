<?php
$servername = "localhost";
$username = "virtualw_api";
$password = "virtualw_api";
$dbname = "virtualw_api";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * from sensor ORDER BY id LIMIT 100";
$query = $conn->query($sql);
$sensor_data =[];
$sensor_date=[];
while($row = $query->fetch_array()){
    if($row['status']=='on' || $row['status']=='ON'){
        $sensor_data[]=1;
    }else{
        $sensor_data[]=0;
    }
    $sensor_date[]=$row['date'];
}


$sql = "SELECT * from alarm ORDER BY id LIMIT 100";
$query = $conn->query($sql);
$alarm_data =[];
$alarm_date=[];
while($row = $query->fetch_array()){
    if($row['status']=='on' || $row['status']=='ON'){
        $alarm_data[]=1;
    }else{
        $alarm_data[]=0;
    }
    $alarm_date[]=$row['date'];
}


$sql = "SELECT * from knob ORDER BY id LIMIT 100";
$query = $conn->query($sql);
$knob_data =[];
$knob_date=[];
while($row = $query->fetch_array()){
    if($row['status']=='on' || $row['status']=='ON'){
        $knob_data[]=1;
    }else{
        $knob_data[]=0;
    }
    $knob_date[]=$row['date'];
}


$sql = "SELECT * from action ORDER BY id LIMIT 100";
$query = $conn->query($sql);
$action_knob_data =[];
$action_knob_date=[];

$action_alarm_data =[];
$action_alarm_date=[];

while($row = $query->fetch_array()){
    if($row['action_on']=='knob' || $row['action_on']=='KNOB'){
        if($row['action']=='on' || $row['action']=='ON'){
            $action_knob_data[]=1;
        }else{
            $action_knob_data[]=0;
        }
        $action_knob_date[]= $row['date'];

        
    }else{
        if($row['action']=='on' || $row['action']=='ON'){
            $action_alarm_data[]=1;
        }else{
            $action_alarm_data[]=0;
        }
        $action_alarm_date[]= $row['date'];
    }
}


$conn->close();
?>

<html>
    
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    </head>
    <body>
        <div class="row">
            <div class='col-md-6'>
                <div id="sensor">
                </div>
            </div>
            <div class='col-md-6'>
                <div id="alarm">
                </div>
            </div>
        </div>
        <div class="row">

            <div class='col-md-6'>
                <div id="knob">
                </div>
            </div>
            <div class='col-md-6'>
                <div id="action_knob">
                </div>
            </div>
            
        </div>
    <div class="row">
        <div class='col-md-6'>
            <div id="action_alarm">
            </div>
        </div>
    </div>
    


    
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.bundle.min.js"></script>
        <script>
            var canvas = document.createElement('canvas');
            var div =document.getElementById('sensor');
            div.appendChild(canvas);
            var ctx = canvas.getContext('2d');
            var data = <?php echo json_encode($sensor_data);?>;
            var config = {
				type: 'line',
				data: {
					labels: <?php echo json_encode($sensor_date);?>,
					datasets: [{
						label: 'Sensor Status ',
						steppedLine: true,
						data: data,
						borderColor: 'blue',
						fill: false,
					}]
				},
				options: {
					responsive: true,
					title: {
						display: true,
						text: 'Sensor Data',
					}
				}
			};
			new Chart(ctx, config);
        </script>
                <script>
            var canvas = document.createElement('canvas');
            var div =document.getElementById('alarm');
            div.appendChild(canvas);
            var ctx = canvas.getContext('2d');
            var data = <?php echo json_encode($alarm_data);?>;
            var config = {
				type: 'line',
				data: {
					labels: <?php echo json_encode($alarm_date);?>,
					datasets: [{
						label: 'Alarm Status ',
						steppedLine: true,
						data: data,
						borderColor: 'red',
						fill: false,
					}]
				},
				options: {
					responsive: true,
					title: {
						display: true,
						text: 'Alarm Data',
					}
				}
			};
			new Chart(ctx, config);
        </script>

        <script>
            var canvas = document.createElement('canvas');
            var div =document.getElementById('knob');
            div.appendChild(canvas);
            var ctx = canvas.getContext('2d');
            var data = <?php echo json_encode($knob_data);?>;
            var config = {
				type: 'line',
				data: {
					labels: <?php echo json_encode($knob_date);?>,
					datasets: [{
						label: 'Knob Status ',
						steppedLine: true,
						data: data,
						borderColor: 'green',
						fill: false,
					}]
				},
				options: {
					responsive: true,
					title: {
						display: true,
						text: 'Knob Data',
					}
				}
			};
			new Chart(ctx, config);
        </script>

        <script>
            var canvas = document.createElement('canvas');
            var div =document.getElementById('action_alarm');
            div.appendChild(canvas);
            var ctx = canvas.getContext('2d');
            var data = <?php echo json_encode($action_alarm_data);?>;
            var config = {
				type: 'line',
				data: {
					labels: <?php echo json_encode($action_alarm_date);?>,
					datasets: [{
						label: 'Action Alarm Status ',
						steppedLine: true,
						data: data,
						borderColor: 'blue',
						fill: false,
					}]
				},
				options: {
					responsive: true,
					title: {
						display: true,
						text: 'Action Alarm Data',
					}
				}
			};
			new Chart(ctx, config);
        </script>

        <script>
            var canvas = document.createElement('canvas');
            var div =document.getElementById('action_knob');
            div.appendChild(canvas);
            var ctx = canvas.getContext('2d');
            var data = <?php echo json_encode($action_knob_data);?>;
            var config = {
				type: 'line',
				data: {
					labels: <?php echo json_encode($action_knob_date);?>,
					datasets: [{
						label: 'Action Knob Status ',
						steppedLine: true,
						data: data,
						borderColor: 'blue',
						fill: false,
					}]
				},
				options: {
					responsive: true,
					title: {
						display: true,
						text: 'Action Knob Data',
					}
				}
			};
			new Chart(ctx, config);
        </script>

    </body>
    
</html>