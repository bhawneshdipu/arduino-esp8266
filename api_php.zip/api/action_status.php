<?php
date_default_timezone_set("Asia/Kolkata");
error_reporting(E_ALL);
ini_set('display_errors', 1);
$servername = "localhost";
$username = "virtualw_api";
$password = "virtualw_api";
$dbname = "virtualw_api";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * from action ORDER BY id ";
$query = $conn->query($sql);
$html ="<table border='2'>";
$html .="<tr>";
$html .="<th>on</th>";
$html .="<th>Action</th>";
$html .="<th>Status</th>";
$html .="</tr>";

while($row = $query->fetch_array()){
    $html.="<tr>";
$html.="<td>".$row['action_on']."</td>";
$html.="<td>".$row['action'].">/td>";
$html.="<td>".$row['status'].">/td>";

$html.="</tr>";
}
$html.="</table>";
echo $html;


/*if(headers_sent()){
    foreach(headers_list() as $header){
        header_remove($header);
    }
}*/
header_remove("Server");
header_remove("X-Powered-By");
header_remove("Upgrade");
header_remove("Vary");
header_remove("Content-Encoding");



$conn->close();
?>