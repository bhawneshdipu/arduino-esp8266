<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$servername = "localhost";
$username = "virtualw_test";
$password = "virtualw_test";
$dbname = "virtualw_test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$name = 'default';
if(isset($_REQUEST['name'])){
	$name = $_REQUEST['name'];
}

$sql = "SELECT * from test ORDER BY id DESC LIMIT 1 ";
$query = $conn->query($sql);
$row = $query->fetch_array();
$data['status'] = $row['name'];
echo "STATUS##".$row['name'];


/*if(headers_sent()){
    foreach(headers_list() as $header){
        header_remove($header);
    }
}*/
header("Server: Apache/2.4.38 (cPanel) OpenSSL/1.0.2q mod_bwlimited/1.4 Phusion_Passenger/5.3.7");
header("X-Powered-By: PHP/5.4.45");
header("Upgrade: h2,h2c");
header("Vary: Accept-Encoding");
header("Content-Encoding: gzip");
header("Content-Length: 54");
header("Content-Type:text/html");


header("Server:none");
header("X-Powered-By:");
header("Upgrade:");
header("Vary:");
header("Content-Encoding:");
header("Content-Length:54");
header("Content-Type:text/html");



header_remove("Server");
header_remove("X-Powered-By");
header_remove("Upgrade");
header_remove("Vary");
header_remove("Content-Encoding");



$conn->close();
?>